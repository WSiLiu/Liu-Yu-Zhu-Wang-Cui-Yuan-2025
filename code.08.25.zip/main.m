%% 1 [Spatial cue]
%% basic design of training situations
clear all;clc;
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();

T0 = 100; % time steps in each situation, including T/2 noisy duration and T/2 stimulus duration
stimulus0 = 1:2;
stimulus1 = 1:2;

N_cue = 2;% number of possible values of hidden cue
T = T0;
stimulus = stimulus0;

num_bio_neurons = 200; % number of WTA neurons
num_train_sets = 500; % number of learning simulations
num_test_trials0 = 500; % number of testing simulations
%% generate sensory stimuli
define = 1; % before simulations, afferent receptive fields are defined.
visualsti(N_cue,define); % design visual stimulus

%% example stimuli for learning simulations
clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue,infor] = generate_patterns1(stimulus,T/2);
%% training simulations with the initial network
tic;
[ex_path1,patterns] = do_learning_task_cause_inference1( 'results/', ...
                  pat_sequences, ... 
                  default_params{:}, ...
                  'pattern_length', size(patterns{1,1},2),...
                  'free_run_seqs',  free_pat_sequences , ... 
                  'pat_labels', pat_labels, ...
                  'free_run_pat_lenghts', size(patterns{1, 1},2), ...
                  'num_bio_neurons', num_bio_neurons, ...             % number of WTA neurons
                  'num_inputs', num_inputs, ...              % number of afferent neurons
                  'free_run_time', size(patterns{1,1},2), ...         % free run time (s)
                  'save_interval', num_train_sets, ...           % number of iterations between 2 save files
                  'num_train_sets', num_train_sets+1, ...        % number of training iterations
                  'collect', '[At,R]', ...
                  'num_epochs', 1, ...
                  'patterns', patterns, ...
                  'sample_method', 'causal', ...
                  'state','movement', ...
                  'T', T, ... % time steps for each situation, including T/2 noisy duration and T/2 stimulus duration
                  'stimulus', stimulus, ... % sequence of stimuli
                  'N_cue',N_cue,... % number of hidden cue
                  'cue', cue, ... % sequence of hidden cue states
                  'changelog_flag', 'N' );
toc;
%% save results and trainded network if necessary
% ex_path1 = ex_path1;save('ex_path1','ex_path1');

%% load results and trainded network if necessary
% ex_path1 = load('ex_path1');ex_path1 = ex_path1.ex_path1;ex_path1
%% basic design of testing situations
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();

stimulus = 1:2;
num_test_trials = num_test_trials0;
%% example stimuli for testing simulations
clear patterns;
clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue,infor] = generate_patterns_test1(stimulus,T/2);
%% tesing simulations with the trained network
eval_mem_task1(ex_path1,num_test_trials,'movement',T,stimulus,N_cue,cue);% run testing simulations
name1 = ['data_set_00000',num2str(num_train_sets),'.mat'];
src_file_name1 = [ex_path1,name1];
name2 = ['mem_task_test',num2str(num_test_trials),'.mat'];
src_file_name2 = [ex_path1,name2]; 
eval_mem_task_collect( ex_path1,num_test_trials,'movement',T,stimulus,src_file_name1,src_file_name2 )% collect neural spikes over testing simulations

%% analyze results over testing situations
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();

stimulus = stimulus1;
num_test_trials = num_test_trials0;
T0 = 100;

path = [ex_path1,'mem_task_test',num2str(num_test_trials),'.mat'];
load(path);
% neural_assemble_spa shows analyses of data. 
% To avoid incompatibility, open M file and run the
% program line by line if nesessary
neural_assemble_spa(test_data,net,stimulus,T0);