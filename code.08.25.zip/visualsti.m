function visualsti(N_cue,define) % N_cue determines number of cues

s1 = [50,50]; % the size of the whole image
s21 = [36,36]; % the size of rectangular stimulus
s22 = [32,8]; 

if define == 1 % define afferent receptive fields if necessary
   Retinalganglionneruon(zeros(s1));
end

orig_stimulus = zeros(s21);
for n1 = (s21(1) - s22(1))/2:((s21(1) - s22(1))/2 + s22(1))
    for n2 = (s21(2) - s22(2))/2:((s21(2) - s22(2))/2 + s22(2))
        orig_stimulus(n1,n2) = 1;
    end
end
% figure;
% imshow(orig_stimulus);
% degrees are generated according to number of cues
degree0 = 180*rand(1,N_cue);
clear degree; clear stim0;
for n_sti = 1:2 % determine orientations of two visual stimuli
    degree(n_sti) = degree0(min(n_sti,end)) + sqrt(3)*randn(1,1);
    % visual stimulus can be by rotating orig_stimulus.
    stim0(:,:,n_sti) = imrotate(orig_stimulus, degree(n_sti), 'bilinear', 'crop');
    % figure;
    % imshow(stim0(:,:,n_sti));
end

% each visual stimulus is presented in a 50*50 image, simultaneously.
bottomgray = 0;
shift_sigma = 3;
clear I0;
I0 = bottomgray * ones([s1,2]);
location = [];
for n_sti = 1:2 % determine location of each stimulus
    clear novel_location
    novel_location = s1/2 - s21/2 + normrnd(0, shift_sigma, 1, 2);
    location = [location;novel_location];
    row_length = [max(1,ceil(novel_location(1))) min(ceil(novel_location(1))+s21(1), s1(1))];
    d_row_length = min(ceil(novel_location(1))+s21(1), s1(1))-max(1,ceil(novel_location(1)));
    column_length = [max(1,ceil(novel_location(2))) min(ceil(novel_location(2))+s21(2),s1(2))];
    d_column_length = min(ceil(novel_location(2))+s21(2),s1(2))-max(1,ceil(novel_location(2)));
    I0(row_length(1):(row_length(2)-1),column_length(1):(column_length(2)-1),n_sti) = stim0(1:d_row_length,1:d_column_length,n_sti);
    % for m = max(1,ceil(novel_location(1))) : min(ceil(novel_location(1))+s21(1), s1(1))  % row
    %    for n = max(1,ceil(novel_location(2))) : min(ceil(novel_location(2))+s21(2),s1(2)) % column
    %        I0(m,n) = stim0(m-5-(n_sti-1)*s1(1)/2,n - shift ,n_sti);
    %    end
    % end
end
if define == 1
  for n_sti = 1:2
  figure;
  imshow(I0(:,:,n_sti));
  end
end


visual_sti = struct;
clear name1;clear retinal_para_right;
name1 = 'retinal_para_right.mat';
retinal_para_right = load(name1);
N_retinal = size(retinal_para_right.retinal_para.sample.sig_center,1);
rate_retinal = zeros(N_retinal,2);
for n_sti = 1:2
    if n_sti == 1
       clear name2;clear retinal_para_left;
       name2 = 'retinal_para_left.mat';
       retinal_para =load(name2);  
    else
       clear name2;clear retinal_para_right;
       name2 = 'retinal_para_left.mat';
       retinal_para =load(name2);
    end
    retinal_para = retinal_para.retinal_para;
   
    f1 = I0(:,:,n_sti);
    for n_retinal = 1:N_retinal
        rate_retinal(n_retinal,n_sti) = 0;
        center_mean = retinal_para.sample.ganglion_center(n_retinal,1:2);
        surround_mean = retinal_para.sample.ganglion_center(n_retinal,3:4);
        center_sig = retinal_para.sample.sig_center(n_retinal,1);
        center_sigma = [center_sig,0;0,center_sig];
        surround_sig = retinal_para.sample.sig_surround(n_retinal,1);
        surround_sigma = [surround_sig,0;0,surround_sig];
        k1 = retinal_para.sample.k(n_retinal,1);
        for n_x = 1:size(f1,2)
            for n_y = 1:size(f1,1)
                if f1(n_y,n_x)~=0
                p = k1*mvnpdf([n_y,n_x],center_mean,center_sigma)-mvnpdf([n_y,n_x],surround_mean,surround_sigma);
                rate_retinal(n_retinal,n_sti) = rate_retinal(n_retinal,n_sti)+p*f1(n_y,n_x);
                end
            end
        end
    end
    clear name1;
    name1 = ['visualsti',num2str(1)];
    visual_sti = setfield(visual_sti,name1,rate_retinal);
end 


save 'visual_sti.mat' -struct visual_sti;
save('location','location');
save('degree','degree');
end