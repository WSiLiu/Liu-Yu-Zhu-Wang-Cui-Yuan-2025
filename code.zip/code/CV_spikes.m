function [CV_pe,CV_real] = CV_spikes(Neu_cout_sti,Neu_cout_pre,N,T1,L,N_sti)
ISI_real = zeros(N,T1,L,N_sti);
for l_style = 1:N_sti
 for l = 1:L
   for n = 1:N
    t1 = 0;t2 = 0;j = 0;
    while t1 < T1
      t1 = min(t1 + 1,T1);
      if (Neu_cout_sti(n,t1,l,l_style)==1)
          t2 = min(t1 + 1,T1);
          while (t2 < T1)&&(Neu_cout_sti(n,t2,l,l_style)==0)
              t2 = min(t2 + 1,T1);
          end
          
          if (Neu_cout_sti(n,t2,l,l_style)==1)&&(Neu_cout_sti(n,t1,l,l_style)==1)
              j = j + 1;
              ISI_real(n,j,l,l_style) = abs(t2-t1);
          end
      end
      
    end
    end
 end
end

ISI_pe = zeros(N,T1,L,N_sti);
for l_style = 1:N_sti
 for l = 1:L
   for n = 1:N
    t1 = 0;t2 = 0;j = 0;
    while t1<T1
      t1 = min(t1 + 1,T1);
      if (Neu_cout_pre(n,t1,l,l_style)==1)
          t2 = min(t1+1,T1);
          while (t2 < T1)&&(Neu_cout_pre(n,t2,l,l_style)==0)
              t2 = min(t2 + 1,T1);
          end
          
          if (Neu_cout_pre(n,t2,l,l_style)==1)&&(Neu_cout_pre(n,t1,l,l_style)==1)
              j = j+1;
              ISI_pe(n,j,l,l_style) = abs(t2-t1);
          end
      end
      
    end
    end
 end
end


clear CV_real;clear CV_pe;
for l_style = 1:N_sti
    ISI_real0 = ISI_real(:,:,:,l_style);
    ISI_real1 = ISI_real0(ISI_real0~=0);
    CV_real(l_style) = std(ISI_real1)/mean(ISI_real1);
    ISI_pe0 = ISI_pe(:,:,:,l_style);
    ISI_pe1 = ISI_pe0(ISI_pe0~=0);
    CV_pe(l_style) = std(ISI_pe1)/mean(ISI_pe1);
end

end