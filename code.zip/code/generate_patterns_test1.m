function [patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,hidden_cue,infor] = generate_patterns_test1(stimulus,T)

pat_sequences = cell(1,1);
patterns = cell(1,1);
pat_labels = cell(1,1);
pat_seq = [];
R0 = [];
cue0 = [];
noisy_stren = 1; % stength of noisy signal
define = 0;% no defination of afferent receptive fields

load('visual_sti.mat');
name = 'visual_sti.mat';
name1 = ['visualsti',num2str(1)];
rate1 = cell2mat(struct2cell(load(name,name1)));
N_neuron = 2*size(rate1,1);

infor = struct;
infor.degree = [];
infor.location = [];

for n_stimulus = 1:length(stimulus)
    rate = [];
    jj = 1;
    N_cue = n_stimulus; % two states of the hidden cue are presented in turn
    visualsti(N_cue,define); % design visual stimulus
    load('degree');load('location');
    infor.degree = [infor.degree;degree];infor.location = [infor.location;location];
    clear rate_simulation;clear cue;
    [rate_simulation,cue] = generate_rate_simulation1(N_cue,noisy_stren,N_neuron,T);
    pat_seq0 = n_stimulus;
    rate = [rate,rate_simulation];
    R0 = [R0,rate];
    pat_seq = [pat_seq,pat_seq0];
    cue0 = [cue0,cue];
    num_inputs = size(rate,1);
end
r_duration2 = zeros(N_neuron,2*T);
R0 = [r_duration2,R0];
pat_seq = [(-1)*ones(size(pat_seq,1),1),pat_seq];
cue0 = [(-1)*ones(size(cue0,1),1),cue0]; % cue0 returns the sequence of values of cue
R0 = R0.*double(R0>0);

pat_sequences{1,1} = pat_seq;
patterns{1,1} = R0;
pat_labels{1,1} = num2str(1);
free_pat_sequences = pat_sequences;
hidden_cue = cue0;

name3 = 'patterns.mat';
name4 = 'pat_sequences.mat';
name5 = 'free_pat_sequences.mat';
name6 = 'pat_labels.mat';
name7 = 'num_inputs.mat';

save(name3,'patterns');
save(name4,'pat_sequences');
save(name5,'free_pat_sequences');
save(name6,'pat_labels');
save(name7,'num_inputs');
end