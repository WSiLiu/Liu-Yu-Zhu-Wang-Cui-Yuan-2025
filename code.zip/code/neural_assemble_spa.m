function neural_assemble_spa(test_data,net,stimulus,T0)

T1 = T0/2;N_neuron = size(test_data{1,1}.Zt,1);L = size(test_data,2);

%% reaction time
clear RT_mu;clear RT_std;clear correction_radio;figure;% calculate averaged value and standard deviation of RT for each situation
for m1 = 1:size(stimulus,2)
  clear iden_time;
  iden_time = net.iden_t(m1,:);
  correction_radio(m1,1) = sum(double(iden_time>=0))/length(iden_time);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end
errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 (size(stimulus,2)+1)]);ylim([-5 50]);
set (gca,'xtick',1:1:size(stimulus,2));

top1 = max(net.iden_t(:));top2 = 0;xrange2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)% frequency histogram of RT for each situation
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['c = ',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
    xrange2 = max(xrange2,ceil(max(iden_time(:))+5));
end
ylim([0 top2]);legend(name1);xlim([0 xrange2]);
for n1 = 1:size(stimulus,2)
    clear aa;
    aa = ['correction radio upon c = ',num2str(n1),' is ',num2str(correction_radio(n1))];
    disp(aa);
end

%% Calculting downstream neural spiking rates for each situation

% Stimulus-induced responses of three groups of ex. neurons
j = 1;clear Z_cout_sti;clear Zleft_cout_sti;clear Zright_cout_sti;
% cout_sti for neural spikes in stimulus duration;
for l_style = 1:size(stimulus,2)
    for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*T0-T0-T1) = 1;
              end
      end
    end
    Z_cout_sti(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0-T1) = 1;
          end
      end
    end
    Zleft_cout_sti(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0-T1) = 1;
          end  
      end
    end
    Zright_cout_sti(:,:,l,l_style) = Zright;
    end
    j = 1+j;
end
% 
j = 1;clear Z_cout_pre;clear Zleft_cout_pre;clear Zright_cout_pre;
% cout_pre for neural spikes in pre-stimulus duration;
for l_style = 1:size(stimulus,2)
   for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zt(n,t) == 1
             Z(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Z_cout_pre(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Zleft_cout_pre(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0) = 1;
          end  
      end
    end
    Zright_cout_pre(:,:,l,l_style) = Zright;
   end
j = 1+j;
end


% neural spiking rates
Z_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Zleft_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_real(n,t,l,l_style) = Z_rate_real(n,t,l,l_style)+Z_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zleft_rate_real(n,t,l,l_style) = Zleft_rate_real(n,t,l,l_style)+Zleft_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_real(n,t,l,l_style) = Zright_rate_real(n,t,l,l_style)+Zright_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            
        end
    end
  end
 end
end

Z_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Zleft_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_pe(n,t,l,l_style) = Z_rate_pe(n,t,l,l_style)+Z_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zleft_rate_pe(n,t,l,l_style) = Zleft_rate_pe(n,t,l,l_style)+Zleft_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_pe(n,t,l,l_style) = Zright_rate_pe(n,t,l,l_style)+Zright_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end
%% save and load neural spiking rates if necessary
% save('Z_rate_pe','Z_rate_pe');save('Z_rate_real','Z_rate_real');save('Z_cout_sti','Z_cout_sti');save('Z_cout_pre','Z_cout_pre');save('Zleft_rate_pe','Zleft_rate_pe');save('Zleft_rate_real','Zleft_rate_real');save('Zleft_cout_sti','Zleft_cout_sti');save('Zleft_cout_pre','Zleft_cout_pre');save('Zright_rate_pe','Zright_rate_pe');save('Zright_rate_real','Zright_rate_real');save('Zright_cout_sti','Zright_cout_sti');save('Zright_cout_pre','Zright_cout_pre');

% aa = load('Z_rate_pe');Z_rate_pe = aa.Z_rate_pe; aa = load('Z_rate_real');Z_rate_real = aa.Z_rate_real; aa = load('Z_cout_sti');Z_cout_sti = aa.Z_cout_sti; aa = load('Z_cout_pre');Z_cout_pre = aa.Z_cout_pre;aa = load('Zleft_rate_pe');Zleft_rate_pe = aa.Zleft_rate_pe;aa = load('Zleft_rate_real');Zleft_rate_real = aa.Zleft_rate_real;aa = load('Zleft_cout_sti');Zleft_cout_sti = aa.Zleft_cout_sti;aa = load('Zleft_cout_pre');Zleft_cout_pre = aa.Zleft_cout_pre;aa = load('Zright_rate_pe');Zright_rate_pe = aa.Zright_rate_pe;aa = load('Zright_rate_real');Zright_rate_real = aa.Zright_rate_real;aa = load('Zright_cout_sti');Zright_cout_sti = aa.Zright_cout_sti;aa = load('Zright_cout_pre');Zright_cout_pre = aa.Zright_cout_pre;
%% neural variability quenching
% neural spiking complex
[Zright_popucomplex_sti,Zright_popucomplex_pre] = neural_groups_spiking_complex(Zright_cout_sti,Zright_cout_pre);
[Zleft_popucomplex_sti,Zleft_popucomplex_pre] = neural_groups_spiking_complex(Zleft_cout_sti,Zleft_cout_pre);
[Z_popucomplex_sti,Z_popucomplex_pre] = neural_groups_spiking_complex(Z_cout_sti,Z_cout_pre);
clear whole_compex;
whole_compex = [Zright_popucomplex_sti(:);Zright_popucomplex_pre(:);Zleft_popucomplex_sti(:);Zleft_popucomplex_pre(:);Z_popucomplex_sti(:);Z_popucomplex_pre(:)];
top = 1.05*max(whole_compex(:));bottom = 0.95*min(whole_compex(:));
for n_simulation = 1:size(Zright_popucomplex_sti,2)
    figure;
    x = [1,4];
    a1 = [Zright_popucomplex_pre(n_simulation),Zright_popucomplex_sti(n_simulation)];
    plot(x,a1,'o-','MarkerSize',15,'Color',[0.2,0.2,0.2]);hold on;
    a2 = [Zleft_popucomplex_pre(n_simulation),Zleft_popucomplex_sti(n_simulation)];
    plot(x,a2,'o-','MarkerSize',15,'Color',[0.4,0.4,0.4]);hold on;
    a3 = [Z_popucomplex_pre(n_simulation),Z_popucomplex_sti(n_simulation)];
    plot(x,a3,'o-','MarkerSize',15,'Color',[0.6,0.6,0.6]);hold on;
    legend('1st group','2nd group','3rd group');
    set(gca,'xlim',[0,5],'XTick',[1,2,3,4],'xticklabel',{'pre-stimulus','','','post-stimulus'},'ylim',[bottom,top]);
end

% responding variability of neural population
Zleft_rate_pe_popu = sum(Zleft_rate_pe,1);
Zright_rate_pe_popu = sum(Zright_rate_pe,1);
Z_rate_pe_popu = sum(Z_rate_pe,1);
Zleft_rate_real_popu =  sum(Zleft_rate_real,1);
Zright_rate_real_popu = sum(Zright_rate_real,1);
Z_rate_real_popu = sum(Z_rate_real,1);

clear Zleft_std_real;clear Zright_std_real;clear Z_std_real;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_real(1,t,l_style) = mean(Zleft_rate_real_popu(1,t,:,l_style));
   Zleft_std_real(1,t,l_style) = std(Zleft_rate_real_popu(1,t,:,l_style));
   Fanoleft_real(1,t,l_style) = (Zleft_std_real(1,t,l_style)^2)/Zleft_mean_real(1,t,l_style);
   Zright_mean_real(1,t,l_style) = mean(Zright_rate_real_popu(1,t,:,l_style));
   Zright_std_real(1,t,l_style) = std(Zright_rate_real_popu(1,t,:,l_style));
   Fanoright_real(1,t,l_style) = (Zright_std_real(1,t,l_style)^2)/Zright_mean_real(1,t,l_style);
   Z_mean_real(1,t,l_style) = mean(Z_rate_real_popu(1,t,:,l_style));
   Z_std_real(1,t,l_style) = std(Z_rate_real_popu(1,t,:,l_style));
   FanoZ_real(1,t,l_style) = (Z_std_real(1,t,l_style)^2)/Z_mean_real(1,t,l_style);
  end
end
clear Zleft_std_pe;clear Zright_std_pe;clear Z_std_pe;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_pe(1,t,l_style) = mean(Zleft_rate_pe_popu(1,t,:,l_style));
   Zleft_std_pe(1,t,l_style) = std(Zleft_rate_pe_popu(1,t,:,l_style));
   Fanoleft_pe(1,t,l_style) = (Zleft_std_pe(1,t,l_style)^2)/Zleft_mean_pe(1,t,l_style);
   Zright_mean_pe(1,t,l_style) = mean(Zright_rate_pe_popu(1,t,:,l_style));
   Zright_std_pe(1,t,l_style) = std(Zright_rate_pe_popu(1,t,:,l_style));
   Fanoright_pe(1,t,l_style) = (Zright_std_pe(1,t,l_style)^2)/Zright_mean_pe(1,t,l_style);
   Z_mean_pe(1,t,l_style) = mean(Z_rate_pe_popu(1,t,:,l_style));
   Z_std_pe(1,t,l_style) = std(Z_rate_pe_popu(1,t,:,l_style));
   FanoZ_pe(1,t,l_style) = (Z_std_pe(1,t,l_style)^2)/Z_mean_pe(1,t,l_style);
  end
end

% plot variability of spikes 1st ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zleft_std_pe,3)
    y1 = [y1,Zleft_std_pe(:,:,n1),Zleft_std_real(:,:,n1)];
end
figure;
plot(x,y1,'color',[0.3,0.3,0.3]);ylim([0.95*min(y1),1.05*max(y1)]);ylabel('SD');hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
end

% plot Fano factor and SD of spikes 2nd ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zright_std_pe,3)
    y1 = [y1,Zright_std_pe(:,:,n1),Zright_std_real(:,:,n1)];
end
figure;
plot(x,y1,'color',[0.3,0.3,0.3]);ylim([0.95*min(y1),1.05*max(y1)]);ylabel('SD');hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
end

% plot Fano factor and SD of spikes 3rd ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Z_std_pe,3)
    y1 = [y1,Z_std_pe(:,:,n1),Z_std_real(:,:,n1)];
end
figure;
plot(x,y1,'color',[0.3,0.3,0.3]);ylim([0.95*min(y1),1.05*max(y1)]);ylabel('SD');hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
end

%% neural sparse responses of three neural groups

clear sparseness_Z;clear sparseness_Zleft;clear sparseness_Zright;
for n_neuron = 1:size(Z_cout_sti,1)% for each neuron in the 3rd ex. group
    % a1 is neural spikes in 1st situation
    a1 = Z_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Z_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Z_rate_sti(1) = mean(mean(a1,2),3);
    Z_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Z_rate_sti)>0
       sparseness_Z(n_neuron) = (mean(Z_rate_sti)^2)/mean(Z_rate_sti.^2);
    else
       sparseness_Z(n_neuron) = 0;
    end
end
for n_neuron = 1:size(Zleft_cout_sti,1)% for each neuron in the 1st ex. group
    % a1 is neural spikes in 1st situation
    a1 = Zleft_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Zleft_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Zleft_rate_sti(1) = mean(mean(a1,2),3);
    Zleft_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Zleft_rate_sti)>0
       sparseness_Zleft(n_neuron) = (mean(Zleft_rate_sti)^2)/mean(Zleft_rate_sti.^2);
    else
       sparseness_Zleft(n_neuron) = 0;
    end
end
clear sparseness_Zright;
for n_neuron = 1:size(Zright_cout_sti,1)% for each neuron in the 1st ex. group
    % a1 is neural spikes in 1st situation
    a1 = Zright_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Zright_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Zright_rate_sti(1) = mean(mean(a1,2),3);
    Zright_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Zright_rate_sti)>0
       sparseness_Zright(n_neuron) = (mean(Zright_rate_sti)^2)/mean(Zright_rate_sti.^2);
    else
       sparseness_Zright(n_neuron) = 0;
    end
end
% plot neural sparseness of three neural groups
clear a1;
xbin = 0:0.2:1;
[a0,b0] = hist(sparseness_Zleft(:),xbin);
a1(:,1) = a0./sum(a0);
[a0,b0] = hist(sparseness_Zright(:),xbin);
a1(:,2) = a0./sum(a0);
[a0,b0] = hist(sparseness_Z(:),xbin);
a1(:,3) = a0./sum(a0);
b1 = b0;
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'neural group ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
legend(aa);
ylim([0,1.1]);title('Neural sparseness');

%% For downstream 3 ex. neural groups, their interactions are calculated through Pearson correlation coefficient

% interactions between pre-stimulus and stimulus-induced ex. neural responses

% X are stimulus-presented 1st ex. neural responses 
% Y are pre-stimulus 1st ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Zleft_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Zleft_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        E_XY = mean(Zreal0.*Zpe0); % E(XY)
        E_Y2 = mean(Zpe0.^2); % E(Y^2)
        E_Y = mean(Zpe0);% EY
        E_X = mean(Zreal0);% EX
        Cov_Y_X_Y = E_XY - E_Y2 + (E_Y)^2 - E_X*E_Y;% cov(X-Y,Y)
        Cov_XY = cov(Zreal0,Zpe0);% matrix of cov(X,Y) 
        Var_X_Y = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);% var(X-Y)
        Var_Y = var(Zpe0);% var(Y)
        p(t,l_style) = Cov_Y_X_Y/sqrt(Var_X_Y*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus and stimulus-induced 1st ex. neural responses');

% X are stimulus-presented 2nd ex. neural responses 
% Y are pre-stimulus 2nd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Zright_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Zright_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        E_XY = mean(Zreal0.*Zpe0); % E(XY)
        E_Y2 = mean(Zpe0.^2); % E(Y^2)
        E_Y = mean(Zpe0);% EY
        E_X = mean(Zreal0);% EX
        Cov_Y_X_Y = E_XY - E_Y2 + (E_Y)^2 - E_X*E_Y;% cov(X-Y,Y)
        Cov_XY = cov(Zreal0,Zpe0);% matrix of cov(X,Y) 
        Var_X_Y = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);% var(X-Y)
        Var_Y = var(Zpe0);% var(Y)
        p(t,l_style) = Cov_Y_X_Y/sqrt(Var_X_Y*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus and stimulus-induced 2nd ex. neural responses');

% X are stimulus-presented 3rd ex. neural responses 
% Y are pre-stimulus 3rd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        E_XY = mean(Zreal0.*Zpe0); % E(XY)
        E_Y2 = mean(Zpe0.^2); % E(Y^2)
        E_Y = mean(Zpe0);% EY
        E_X = mean(Zreal0);% EX
        Cov_Y_X_Y = E_XY - E_Y2 + (E_Y)^2 - E_X*E_Y;% cov(X-Y,Y)
        Cov_XY = cov(Zreal0,Zpe0);% matrix of cov(X,Y) 
        Var_X_Y = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);% var(X-Y)
        Var_Y = var(Zpe0);% var(Y)
        p(t,l_style) = Cov_Y_X_Y/sqrt(Var_X_Y*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus and stimulus-induced 3rd ex. neural responses');

% interactions between stimulus-induced 1st and 2nd ex. neural responses
% X are stimulus-presented 1st ex. neural responses
% X1 are pre-stimulus 1st ex. neural responses
% Y are stimulus-presented 2nd ex. neural responses
% Y1 are pre-stimulus 2nd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal1;clear Zpe1;
        clear Zreal2;clear Zpe2;
        % Zreal1 are the temporal 1st ex. neural populational responses in stimulus-presented duration
        Zreal1 = sum(Zleft_rate_real(:,t,:,l_style),1);Zreal1 = Zreal1(:);
        % Zpe1 are the temporal 1st ex. neural populational responses in pre-stimulus duration
        Zpe1 = sum(Zleft_rate_pe(:,t,:,l_style),1);Zpe1 = Zpe1(:);
        % Zreal2 are the temporal 2nd ex. neural populational responses in stimulus-presented duration
        Zreal2 = sum(Zright_rate_real(:,t,:,l_style),1);Zreal2 = Zreal2(:);
        % Zpe2 are the temporal 2nd ex. neural populational responses in pre-stimulus duration
        Zpe2 = sum(Zright_rate_pe(:,t,:,l_style),1);Zpe2 = Zpe2(:);

        E_XY = mean(Zreal1.*Zreal2); %E(XY)
        E_XY1 = mean(Zreal1.*Zpe2); %E(XY1)
        E_X1Y = mean(Zpe1.*Zreal2); %E(X1Y)
        E_X1Y1 = mean(Zpe1.*Zpe2); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal1) - mean(Zpe1); %E(Z1)
        EZ2 = mean(Zreal2) - mean(Zpe2); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal1,Zpe1); % matrix of Zreal1 and Zpe1
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Zreal2,Zpe2); % matrix of Zreal2 and Zpe2
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced 1st and 2nd ex. neural responses');


% interactions between stimulus-induced 2nd and 3rd ex. neural responses
% X are stimulus-presented 2nd ex. neural responses
% X1 are pre-stimulus 2nd ex. neural responses
% Y are stimulus-presented 3rd ex. neural responses
% Y1 are pre-stimulus 3rd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal1;clear Zpe1;
        clear Zreal2;clear Zpe2;
        % Zreal1 are the temporal 2nd ex. neural populational responses in stimulus-presented duration
        Zreal1 = sum(Zright_rate_real(:,t,:,l_style),1);Zreal1 = Zreal1(:);
        % Zpe1 are the temporal 2nd ex. neural populational responses in pre-stimulus duration
        Zpe1 = sum(Zright_rate_pe(:,t,:,l_style),1);Zpe1 = Zpe1(:);
        % Zreal2 are the temporal 3rd ex. neural populational responses in stimulus-presented duration
        Zreal2 = sum(Z_rate_real(:,t,:,l_style),1);Zreal2 = Zreal2(:);
        % Zpe2 are the temporal 3rd ex. neural populational responses in pre-stimulus duration
        Zpe2 = sum(Z_rate_pe(:,t,:,l_style),1);Zpe2 = Zpe2(:);

        E_XY = mean(Zreal1.*Zreal2); %E(XY)
        E_XY1 = mean(Zreal1.*Zpe2); %E(XY1)
        E_X1Y = mean(Zpe1.*Zreal2); %E(X1Y)
        E_X1Y1 = mean(Zpe1.*Zpe2); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal1) - mean(Zpe1); %E(Z1)
        EZ2 = mean(Zreal2) - mean(Zpe2); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal1,Zpe1); % matrix of Zreal1 and Zpe1
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Zreal2,Zpe2); % matrix of Zreal2 and Zpe2
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced 2nd and 3rd ex. neural responses');


% interactions between stimulus-induced 1st and 3rd ex. neural responses
% X are stimulus-presented 1st ex. neural responses
% X1 are pre-stimulus 1st ex. neural responses
% Y are stimulus-presented 3rd ex. neural responses
% Y1 are pre-stimulus 3rd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal1;clear Zpe1;
        clear Zreal2;clear Zpe2;
        % Zreal1 are the temporal 2nd ex. neural populational responses in stimulus-presented duration
        Zreal1 = sum(Zleft_rate_real(:,t,:,l_style),1);Zreal1 = Zreal1(:);
        % Zpe1 are the temporal 2nd ex. neural populational responses in pre-stimulus duration
        Zpe1 = sum(Zleft_rate_pe(:,t,:,l_style),1);Zpe1 = Zpe1(:);
        % Zreal2 are the temporal 3rd ex. neural populational responses in stimulus-presented duration
        Zreal2 = sum(Z_rate_real(:,t,:,l_style),1);Zreal2 = Zreal2(:);
        % Zpe2 are the temporal 3rd ex. neural populational responses in pre-stimulus duration
        Zpe2 = sum(Z_rate_pe(:,t,:,l_style),1);Zpe2 = Zpe2(:);

        E_XY = mean(Zreal1.*Zreal2); %E(XY)
        E_XY1 = mean(Zreal1.*Zpe2); %E(XY1)
        E_X1Y = mean(Zpe1.*Zreal2); %E(X1Y)
        E_X1Y1 = mean(Zpe1.*Zpe2); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal1) - mean(Zpe1); %E(Z1)
        EZ2 = mean(Zreal2) - mean(Zpe2); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal1,Zpe1); % matrix of Zreal1 and Zpe1
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Zreal2,Zpe2); % matrix of Zreal2 and Zpe2
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced 1st and 3rd ex. neural responses');


%% calcuate neural contributions in cue combination
%% neural contributions in network responses
% PCA of ex. neural responses over different situations
neuralpopulation_rate = []; % neural responses at each time step is variable
for n1 = 1:size(Z_rate_real,4) % over situations
    for t = 1:size(Z_rate_real,2) % for each time step
        % neural population is averaged over simulation
        clear neural_responses0;
        neural_responses0 = [mean(Zleft_rate_real(:,t,:,n1),3)',mean(Zright_rate_real(:,t,:,n1),3)',mean(Z_rate_real(:,t,:,n1),3)'];

        neuralpopulation_rate = [neuralpopulation_rate;neural_responses0];
    end
end
clear Sigma;
Sigma = cov(neuralpopulation_rate); % covariance matrix of neural responses

[COEFF, SCORE, latent] = pca(neuralpopulation_rate); % COEFF is the coefficient in PCA
% novel variables are neuralpopulation_rate*COEFF describe the responses of
% the network at a given time step
save('COEFF','COEFF');
contri_intergra = sum(latent(1:3))/sum(latent)

PCA_tem_real0 = [];
for n1 = 1:size(Z_rate_real,4) % for each situation
    for n2 = 1:size(Z_rate_real,3) % for each simulation
        for t = 1:size(Z_rate_real,2) % for each time step
           clear neural_responses0;
           neural_responses0 = [Zleft_rate_real(:,t,n2,n1)',Zright_rate_real(:,t,n2,n1)',Z_rate_real(:,t,n2,n1)'];
           PCA_tem_real0(:,t,n1,n2) = (neural_responses0 * COEFF(:,1:3))';
        end
    end
end
PCA_tem_pe0 = [];
for n1 = 1:size(Z_rate_pe,4) % for each situation
    for n2 = 1:size(Z_rate_pe,3) % for each simulation
        for t = 1:size(Z_rate_pe,2) % for each time step
           clear neural_responses0;
           neural_responses0 = [Zleft_rate_pe(:,t,n2,n1)',Zright_rate_pe(:,t,n2,n1)',Z_rate_pe(:,t,n2,n1)'];
           PCA_tem_pe0(:,t,n1,n2) = (neural_responses0 * COEFF(:,1:3))';
        end
    end
end
PCA_tem_pe = mean(PCA_tem_pe0,4);
PCA_tem_real = mean(PCA_tem_real0,4);
clear PCA_tem;
for n1 = 1:size(Z_rate_real,4) % for each situation
    PCA_tem(:,:,n1) = [PCA_tem_pe(:,:,n1),PCA_tem_real(:,:,n1)];
end
d0 = 0.48/size(PCA_tem,2)*[1 1 1];
figure;
for n1 = 1:size(Z_rate_real,4) % for each situation
    for t = 1:size(PCA_tem,2)-1
    x1 = PCA_tem(1,t,n1);x2 = PCA_tem(1,t+1,n1);
    x = [x1 x2];
    y1 = PCA_tem(2,t,n1);y2 = PCA_tem(2,t+1,n1);
    y = [y1 y2];
    z1 = PCA_tem(3,t,n1);z2 = PCA_tem(3,t+1,n1);
    z = [z1 z2];
    if t<=size(PCA_tem,2)/2 
        facecolor = [0.5,0.5,0.5]*(n1-1)+d0*t; % the pre-stimulus duration
        plot3(x1, y1, z1,'o','Markersize',5,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t,'MarkerFaceColor',facecolor);hold on;
    else
        facecolor = [0.5,0.5,0.5]*(n1-1)+d0*t; % the stimulus-presented duration
        plot3(x1, y1, z1,'o','Markersize',10,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t,'MarkerFaceColor',facecolor);hold on;
    end
    plot3(x, y, z,'-','LineWidth',5,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t);hold on;
    end
end
grid on;
xlabel('PC1');ylabel('PC2');zlabel('PC3');

%  correlation coefficients between neural responses and principal components
clear rho
for n_neuron = 1:size(neuralpopulation_rate,2)
    for n_com = 1:size(latent,1)
        rho(n_neuron,n_com) = sqrt(latent(n_com))/sqrt(Sigma(n_neuron,n_neuron))*COEFF(n_neuron,n_com);
    end
end
clear neural_con
for n_neuron = 1:size(neuralpopulation_rate,2)
    clear squa_rho
    squa_rho = rho(n_neuron,:).^2;
    neural_con(n_neuron) = squa_rho(1);% neural contributions upon first principal component
    % neural_con(n_neuron) = sum(squa_rho,1:3); % neural contributions upon
    % first three principal components
end

save('neural_con','neural_con');

clear a0;clear b0;clear a1;clear b1;
[a0,b0] = hist(neural_con(:),5);
a1 = a0./sum(a0);
b1 = b0;
figure;
b = bar(b1,a1);
b.FaceColor = ([0.3 0.3 0.3]);hold on;
ylim([0,1.1]);title('Neural contributions in network responses');

% contributions of 3 ex. neural group in network responses
neural_group_con_resp = zeros(3,N_neuron);
for n1 = 1:3
    neural_group_con_resp(n1,:) = neural_con(1,((n1-1)*N_neuron+1):(n1*N_neuron));
end

clear a1;
xbin = 0:0.2:1;
for n1 = 1:3
    clear con_resp0;
    con_resp0 = neural_group_con_resp(n1,:);
    [a0,b0] = hist(con_resp0(:),xbin);
    a1(:,n1) = a0./sum(a0);
end
b1 = b0;
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'neural group ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
legend(aa);
ylim([0,1.1]);title('Contributions of neural groups in network responses');

%% neural contributions in identifications

Z_spike_real_contri = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each situation
 for l = 1:L % for each simulation
  clear T2;T2 = net.iden_t(l_style,l);
  Z_spike_real_contri(:,l,l_style) = Z_cout_sti(:,T2,l,l_style); % neural spikes at first correct identifications
 end
end

Zleft_spike_real_contri = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each situation
 for l = 1:L % for each simulation
  clear T2;T2 = net.iden_t(l_style,l);
  Zleft_spike_real_contri(:,l,l_style) = Zleft_cout_sti(:,T2,l,l_style); % neural spikes at first correct identifications
 end
end

Zright_spike_real_contri = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each situation
 for l = 1:L % for each simulation
  clear T2;T2 = net.iden_t(l_style,l);
  Zright_spike_real_contri(:,l,l_style) = Zright_cout_sti(:,T2,l,l_style); % neural spikes at first correct identifications
 end
end

clear Z_cluster;
for m = 1:size(Z_cout_sti,4)
    clear cluster0
    cluster0 = net.action{1,m};
    Z_cluster(:,:,m) = cluster0;
end

Zleft_distance = zeros(size(Zleft_cout_sti,1),size(Zleft_cout_sti,4));Zright_distance = zeros(size(Zright_cout_sti,1),size(Zright_cout_sti,4));Z_distance = zeros(size(Z_cout_sti,1),size(Z_cout_sti,4));
Zleft_contri = Zleft_distance;Zright_contri = Zright_distance;Z_contri = Z_distance;

% distance induced by 1st neural group in inference to different situations
for m = 1:size(Zleft_cout_sti,4)% for each situation
 for ll = 1:size(Zleft_cout_sti,3)% for each simulation
     clear Zleft_distance0;
     for v = 1:size(Z_cluster,2) % for each vector in each clustering martix
         clear Z_cluster0;
         Z_cluster0 = Z_cluster(1:N_neuron,v,m);
         Zleft_distance0(:,v) = Zleft_spike_real_contri(:,ll,m) - Z_cluster0;
     end
     Zleft_distance(:,m) = Zleft_distance(:,m) + sum((Zleft_distance0.^2),2);
 end
end
% distance induced by 2nd neural group in inference to different situations
for m = 1:size(Zright_cout_sti,4)% for each situation
 for ll = 1:size(Zright_cout_sti,3)% for each simulation
     clear Zright_distance0;
     for v = 1:size(Z_cluster,2) % for each vector in each clustering martix
         clear Z_cluster0;
         Z_cluster0 = Z_cluster(N_neuron+1:2*N_neuron,v,m);
         Zright_distance0(:,v) = Zright_spike_real_contri(:,ll,m) - Z_cluster0;
     end
     Zright_distance(:,m) = Zright_distance(:,m) + sum((Zright_distance0.^2),2);
 end
end
% distance induced by 3rd neural group in inference to different situations
for m = 1:size(Z_cout_sti,4)% for each situation
 for ll = 1:size(Z_cout_sti,3)% for each simulation
     clear Z_distance0;
     for v = 1:size(Z_cluster,2) % for each vector in each clustering martix
         clear Z_cluster0;
         Z_cluster0 = Z_cluster(2*N_neuron+1:3*N_neuron,v,m);
         Z_distance0(:,v) = Z_spike_real_contri(:,ll,m) - Z_cluster0;
     end
     Z_distance(:,m) = Z_distance(:,m) + sum((Z_distance0.^2),2);
 end
end

% with the Maximum of distance, neural contributions in inference are
% measured
clear max_distance;clear min_distance;
for m = 1:size(Z_distance,2)%
    clear neural_distance0
    neural_distance0 = [Zleft_distance(:,m),Zright_distance(:,m),Z_distance(:,m)];
    max_distance(m) = max(neural_distance0(:));
    min_distance(m) = min(neural_distance0(:));% common parameters for comparisons
    % contributions of 3 neural groups in identifications upon two
    % situations
    Zleft_contri(:,m) = (max_distance(m) - Zleft_distance(:,m))/(max_distance(m)-min_distance(m));
    Zright_contri(:,m) = (max_distance(m) - Zright_distance(:,m))/(max_distance(m)-min_distance(m));
    Z_contri(:,m) = (max_distance(m) - Z_distance(:,m))/(max_distance(m)-min_distance(m));
end

for m = 1:size(Z_distance,2) % for each situation
    neural_con_identi = [Zleft_contri(:,m)';Zright_contri(:,m)';Z_contri(:,m)'];
    clear a1;clear d0;
    d0 = (max(neural_con_identi(:)) - min(neural_con_identi(:)))/5;
    xbin = min(neural_con_identi(:)):d0:max(neural_con_identi(:));
    clear a0;clear a1;clear b0;clear b1;
    [a0,b0] = hist(neural_con_identi(:),xbin);
    a1 = a0./sum(a0);
    b1 = b0;
    figure;
    b = bar(b1,a1,'FaceColor',[0.3,0.3,0.3]*m);
    ylim([0,1.1]);title('Neural contributions in identifications');
end

for m = 1:size(Z_distance,2) % for each situation

    neural_group_con_identi = [Zleft_contri(:,m)';Zright_contri(:,m)';Z_contri(:,m)'];
    clear a1;clear d0;
    d0 = (max(neural_group_con_identi(:)) - min(neural_group_con_identi(:)))/5;
    xbin = min(neural_group_con_identi(:)):d0:max(neural_group_con_identi(:));
    for n1 = 1:3
     clear con_identi0;
     con_identi0 = neural_group_con_identi(n1,:);
     [a0,b0] = hist(con_identi0(:),xbin);
     a1(:,n1) = a0./sum(a0);
    end
    b1 = b0;
    figure;
    b = bar(b1,a1);
    aa = [];
    for nn = 1:3
        aa = [aa;'neural group ',num2str(nn)];
        b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
    end
    legend(aa,'Location', 'northwest');
    ylim([0,1.1]);title('Contributions of neural groups in identifications');
end

% clear h;clear p;
% [h,p,ci,stats] = ttest2(Z_contri(:,1),Z_contri(:,2));
% [h,p]

%% For each downstream neuron, its responsivity is calculated through a Wilcoxon rank-sum test as one attribution
Z_spiketrain_real_avetime = sum(Z_cout_sti,2);
Z_spiketrain_pe_avertime = sum(Z_cout_pre,2);
Z_spiketrain_Wilcoxon_test2 = zeros(size(Z_spiketrain_real_avetime,1),size(Z_spiketrain_real_avetime,4));
for nn = 1:size(Z_spiketrain_real_avetime,1)
    for mm = 1:size(Z_spiketrain_real_avetime,4)
    clear a;clear b;
    % for each neuron, a records its responses to sti and b records its
    % spontaneous activities
     a = Z_spiketrain_real_avetime(nn,1,:,mm);
     b = Z_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     % neurons with significant responses to sti are selected
     Z_spiketrain_Wilcoxon_test2(nn,mm) = h*double((mean(a)>0)&&(mean(b)>0));
    end
end
Zleft_spiketrain_real_avetime = sum(Zleft_cout_sti,2);
Zleft_spiketrain_pe_avertime = sum(Zleft_cout_pre,2);
Zleft_spiketrain_Wilcoxon_test2 = zeros(size(Zleft_spiketrain_real_avetime,1),size(Zleft_spiketrain_real_avetime,4));
for nn = 1:size(Zleft_spiketrain_real_avetime,1)
    for mm = 1:size(Zleft_spiketrain_real_avetime,4)
    clear a;clear b;
    % for each neuron, a records its responses to sti and b records its
    % spontaneous activities
     a = Zleft_spiketrain_real_avetime(nn,1,:,mm);
     b = Zleft_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     % neurons with significant responses to sti are selected
     Zleft_spiketrain_Wilcoxon_test2(nn,mm) = h*double((mean(a)>0)&&(mean(b)>0));
    end
end
Zright_spiketrain_real_avetime = sum(Zright_cout_sti,2);
Zright_spiketrain_pe_avertime = sum(Zright_cout_pre,2);
Zright_spiketrain_Wilcoxon_test2 = zeros(size(Zright_spiketrain_real_avetime,1),size(Zright_spiketrain_real_avetime,4));
for nn = 1:size(Zright_spiketrain_real_avetime,1)
    for mm = 1:size(Zright_spiketrain_real_avetime,4)
    clear a;clear b;
    % for each neuron, a records its responses to sti and b records its
    % spontaneous activities
     a = Zright_spiketrain_real_avetime(nn,1,:,mm);
     b = Zright_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     % neurons with significant responses to sti are selected
     Zright_spiketrain_Wilcoxon_test2(nn,mm) = h*double((mean(a)>0)&&(mean(b)>0));
    end
end

% Neural assembles are determined by the Wilcoxon rank-sum test
Zleft_assembles = cell(3,1);Zright_assembles = cell(3,1);Z_assembles = cell(3,1);
Zleft_assembles = Neuralassemble(Zleft_assembles,Zleft_spiketrain_Wilcoxon_test2);
Zright_assembles = Neuralassemble(Zright_assembles,Zright_spiketrain_Wilcoxon_test2);
Z_assembles = Neuralassemble(Z_assembles,Z_spiketrain_Wilcoxon_test2);


figure;
shape = ['+','X','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:(net.num_ex_right/20)
     n_neuron = n_neuron + 1;n_assemble0 = 0;% n_assemble0 is number of assembles each neuron belongs to.
     for m = 1:size(Zleft_assembles,1)
            if ~isempty(find(n_neuron == Zleft_assembles{m,1}(:)))
               n_assembel = m;
               n_assemble0 = n_assemble0 + 1;
               a = x;b = y;
               if n_assemble0 == 1
                   plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               elseif n_assemble0 > 1
                   plot(a,b,shape(4),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               end
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');

figure;
shape = ['+','X','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:(net.num_ex_right/20)
     n_neuron = n_neuron + 1;n_assemble0 = 0;% n_assemble0 is number of assembles each neuron belongs to.
     for m = 1:size(Zright_assembles,1)
            if ~isempty(find(n_neuron == Zright_assembles{m,1}(:)))
               n_assembel = m;
               n_assemble0 = n_assemble0 + 1;
               a = x;b = y;
               if n_assemble0 == 1
                   plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               elseif n_assemble0 > 1
                   plot(a,b,shape(4),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               end
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');

figure;
shape = ['+','X','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:(net.num_ex_right/20)
     n_neuron = n_neuron + 1;n_assemble0 = 0;% n_assemble0 is number of assembles each neuron belongs to.
     for m = 1:size(Z_assembles,1)
            if ~isempty(find(n_neuron == Z_assembles{m,1}(:)))
               n_assembel = m;
               n_assemble0 = n_assemble0 + 1;
               a = x;b = y;
               if n_assemble0 == 1
                   plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               elseif n_assemble0 > 1
                   plot(a,b,shape(4),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               end
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');


%% Contributions of neural assembles in network responses
N_assemble = size(Z_assembles,1); % number of neural assembles
% load('neural_con')
% for 1st neural group
neural_contribution_responses_Zleft = [];
clear neural_con0 
neural_con0 = neural_con(1,1:N_neuron);
for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];
        neuron = Zleft_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        clear a1;
        a1 = mean(neural_con0(1,neuron));
        if isnan(a1)
            a1 = 0;
        end
        neural_contribution_responses_Zleft = [neural_contribution_responses_Zleft,a1];
end
color = [0.3,0.3,0.3];
figure;hold on;
h = bar(neural_contribution_responses_Zleft);
h.FaceColor = color;
set(gca,'XTickLabel',[]);title('Contributions of neural ensembles in 1st neural group in responses');


% for 2nd neural group
neural_contribution_responses_Zright = [];
clear neural_con0 
neural_con0 = neural_con(1,N_neuron+1:2*N_neuron);
for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];
        neuron = Zright_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        clear a1;
        a1 = mean(neural_con0(1,neuron));
        if isnan(a1)
            a1 = 0;
        end
        neural_contribution_responses_Zright = [neural_contribution_responses_Zright,a1];
end
color = [0.5,0.5,0.5];
figure;hold on;
h = bar(neural_contribution_responses_Zright);
h.FaceColor = color;
set(gca,'XTickLabel',[]);title('Contributions of neural ensembles in 2nd neural group in responses');



% for 3rd neural group
neural_contribution_responses_Z = [];
clear neural_con0 
neural_con0 = neural_con(1,2*N_neuron+1:3*N_neuron);
for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];
        neuron = Z_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        clear a1;
        a1 = mean(neural_con0(1,neuron)); % average 
        if isnan(a1)
            a1 = 0;
        end
        neural_contribution_responses_Z = [neural_contribution_responses_Z,a1];
end
color = [0.7,0.7,0.7];
figure;hold on;
h = bar(neural_contribution_responses_Z);
h.FaceColor = color;
set(gca,'XTickLabel',[]);title('Contributions of neural ensembles in 3rd neural group in responses');

%% Contributions of neural assembles in identificaitions upon situations
N_assemble = size(Z_assembles,1); % number of neural assembles
N_situation = size(Z_rate_real,4); % number of situations

clear Neural_assemb_contri_Zleft;
Neural_assemb_contri_Zleft = zeros(N_situation,N_assemble);
for n_situation = 1:N_situation
  for n_assemble = 1:N_assemble
    % find series numbers of neurons in each assembles
    neuron = [];
    neuron = Zleft_assembles{n_assemble,1}(:);
    neuron = neuron(neuron>0);
    neural_assemb_contri = Zleft_contri(neuron,n_situation);
    % contributions of neural assemble are averaged over selected PCs and neurons
    Neural_assemb_contri_Zleft(n_situation,n_assemble) = mean(neural_assemb_contri(:));%sum(neural_assemb_contri(:));
  end
end
figure;hold on;
h = bar(Neural_assemb_contri_Zleft);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of neural ensembles in 1st neural group in identifications');


clear Neural_assemb_contri_Zright;
Neural_assemb_contri_Zright = zeros(N_situation,N_assemble);
for n_situation = 1:N_situation
    for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];neural_assemb_contri = [];
        neuron = Zright_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        neural_assemb_contri = Zright_contri(neuron,n_situation);
        % contributions of neural assemble are averaged over selected PCs and neurons
        Neural_assemb_contri_Zright(n_situation,n_assemble) = mean(neural_assemb_contri(:));%sum(neural_assemb_contri(:));
    end
end
figure;hold on;
h = bar(Neural_assemb_contri_Zright);
x = 1:N_situation;
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of neural ensembles in 2nd neural group in identifications');


clear Neural_assemb_contri_Z;
Neural_assemb_contri_Z = zeros(N_situation,N_assemble);
for n_situation = 1:N_situation
    for n_assemble = 1:N_assemble
        neuron = [];neural_assemb_contri = [];
        % find series numbers of neurons in each assembles
        neuron = Z_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        neural_assemb_contri = Z_contri(neuron,n_situation);
        Neural_assemb_contri_Z(n_situation,n_assemble) = mean(neural_assemb_contri(:));
    end
    % total = sum(Neural_assemb_contri_Z(n_situation,:));
    % Neural_assemb_contri_Z(n_situation,:) = Neural_assemb_contri_Z(n_situation,:)./total;
end
figure;hold on;
h = bar(Neural_assemb_contri_Z);
x = 1:N_situation;
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of neural ensembles in 3rd neural group in identifications');


%% Contributions of overlaps of neural assembles
N_assemble = size(Z_assembles,1); % number of neural assembles
neural_contribution_overlaps_combination = [];
neural_contribution_overlaps_identification = [];
% load('neural_con')

% for 1st neural group
% overlaps of first two neural assembles
clear neural_con0 
neural_con0 = neural_con(1,1:N_neuron);
clear neural_overlap1
neural_overlap1 = intersect(Zleft_assembles{1,1}(:),Zleft_assembles{2,1}(:));
neural_contribution_overlaps_combination(1,:) = mean(neural_con0(1,neural_overlap1));
for ii = 1:2
    neural_contribution_overlaps_identification(1,ii) = mean(Zleft_contri(neural_overlap1,ii));
end

% for 2nd neural group
% overlaps of first two neural assembles
clear neural_con0 
neural_con0 = neural_con(1,N_neuron+1:2*N_neuron);
clear neural_overlap2
neural_overlap2 = intersect(Zright_assembles{1,1}(:),Zright_assembles{2,1}(:));
neural_contribution_overlaps_combination(2,:) = mean(neural_con0(1,neural_overlap2));
for ii = 1:2
     neural_contribution_overlaps_identification(2,ii) = mean(Zright_contri(neural_overlap2,ii));
end

% for 3rd neural group
% overlaps of first two neural assembles
clear neural_con0 
neural_con0 = neural_con(1,2*N_neuron+1:3*N_neuron);
clear neural_overlap3
neural_overlap3 = intersect(Z_assembles{1,1}(:),Z_assembles{2,1}(:));
neural_contribution_overlaps_combination(3,:) = mean(neural_con0(1,neural_overlap3));
for ii = 1:2
     neural_contribution_overlaps_identification(3,ii) = mean(Z_contri(neural_overlap2,ii));
end

N_neuralgroup = 3;
x = 1:N_neuralgroup;
figure;
h = bar(neural_contribution_overlaps_combination,'FaceColor',[0.5,0.5,0.5]);hold on;
xlim([0 4]);title('Contributions of overlaps of neural assembles on cue combination');
plot(x,neural_contribution_overlaps_combination,'o');


figure;hold on;
h = bar(neural_contribution_overlaps_identification);
x = 1:N_situation;
color = [0.4,0.4,0.4;0.8,0.8,0.8];
for mm = 1:N_situation
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
title('Contributions of overlaps of neural assembles in identification');

%% different direction distance




%% For each pair of downstream neurons, their responding similarity is calculated through the normalized mutual informaiton
Z_spiketrain_real_avetime = sum(Z_cout_sti,2);
Zleft_spiketrain_real_avetime = sum(Zleft_cout_sti,2);
Zright_spiketrain_real_avetime = sum(Zright_cout_sti,2);
% NMI indicates neural responding similarity with connections considered
[MI,NMI_BB] = Neural_NMI(Z_spiketrain_real_avetime,Z_spiketrain_real_avetime,net.VBtoB0,net.VBtoB0);
[MI,NMI_LL] = Neural_NMI(Zleft_spiketrain_real_avetime,Zleft_spiketrain_real_avetime,net.VLtoL0,net.VLtoL0);
[MI,NMI_RR] = Neural_NMI(Zright_spiketrain_real_avetime,Zright_spiketrain_real_avetime,net.VRtoR0,net.VRtoR0);
[MI,NMI_BR] = Neural_NMI(Z_spiketrain_real_avetime,Zright_spiketrain_real_avetime,net.VBtoR0,net.VRtoB0);
[MI,NMI_BL] = Neural_NMI(Z_spiketrain_real_avetime,Zleft_spiketrain_real_avetime,net.VBtoL0,net.VLtoB0);
[MI,NMI_RL] = Neural_NMI(Zright_spiketrain_real_avetime,Zleft_spiketrain_real_avetime,net.VRtoL0,net.VLtoR0);


% Plot NMI of three ex. neural groups
clear mu;clear error;
figure;grid on;
n1 = 1;n2 = 1;% 1st neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_LL{:,1};NMI2 = NMI_LL{:,2};
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
% For two situations, z1 and z2 are averaged NMI between neural groups
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5],'MarkerSize', 20);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5],'MarkerSize', 20);
hold on;grid on;

n1 = 2;n2 = 2;% 2nd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_RR{:,1};NMI2 = NMI_RR{:,2};
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
% For two situations, z1 and z2 are averaged NMI between neural groups
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5],'MarkerSize', 20);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5],'MarkerSize', 20);
hold on;

n1 = 3;n2 = 3;% 3rd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_BB{:,1};NMI2 = NMI_BB{:,2};
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
% For two situations, z1 and z2 are averaged NMI between neural groups 
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5],'MarkerSize', 20);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5],'MarkerSize', 20);
hold on;


clear mu;clear error;
n1 = 1;n2 = 2;% 1st and 2nd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_RL{:,1};NMI2 = NMI_RL{:,2};
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
% For two situations, z1 and z2 are averaged NMI between neural groups
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5],'MarkerSize', 20);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5],'MarkerSize', 20);
hold on;

clear mu;clear error;
n1 = 1;n2 = 3;% 1st and 3rd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_BL{:,1};NMI2 = NMI_BL{:,2};
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
% For two situations, z1 and z2 are averaged NMI between neural groups
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5],'MarkerSize', 20);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5],'MarkerSize', 20);
hold on;

clear mu;clear error;
n1 = 2;n2 = 3;% 2nd and 3rd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_BR{:,1};NMI2 = NMI_BR{:,2};
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
% For two situations, z1 and z2 are averaged NMI between neural groups
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5],'MarkerSize', 20);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5],'MarkerSize', 20);
hold on;
set(gca,'xlim',[0.5 3.5],'ylim',[0.5 3.5],'XTick',[1 2 3],'YTick',[1 2 3]);

%% For downstream neural groups, their interactions are calculated through Pearson correlation coefficient
N_situation = size(stimulus,2);
Zleft_rate_pe_popu = sum(Zleft_rate_pe,1);
Zright_rate_pe_popu = sum(Zright_rate_pe,1);
Z_rate_pe_popu = sum(Z_rate_pe,1);
Zleft_rate_real_popu =  sum(Zleft_rate_real,1);
Zright_rate_real_popu = sum(Zright_rate_real,1);
Z_rate_real_popu = sum(Z_rate_real,1);

p_LR = neural_correlation(N_situation,T1,Zleft_rate_real_popu,Zright_rate_real_popu);
p_LB = neural_correlation(N_situation,T1,Zleft_rate_real_popu,Z_rate_real_popu);
p_RB = neural_correlation(N_situation,T1,Zright_rate_real_popu,Z_rate_real_popu);
figure;aa = [];
for mm = 1:N_situation
    if mm == 1
        type0 = '-';
    else
        type0 = '--';
    end
    t = 1:T1;
    x1 = p_LR(:,mm);
    plot(t,x1,type0,'color',[0.2,0.2,0.2]);
    aa = [aa;'between 1st and 2nd groups'];
    hold on;
    x2 = p_LB(:,mm);
    plot(t,x2,type0,'color',[0.5,0.5,0.5]);
    aa = [aa;'between 1st and 3rd groups'];
    hold on;
    x3 = p_RB(:,mm);
    plot(t,x3,type0,'color',[0.8,0.8,0.8]);
    aa = [aa;'between 2nd and 3rd groups'];
    xlabel('time step');title('Neural interactions')
end
legend(aa);

% calculate responses of neural assembles
Zleft_rate_real_assemble = cell(size(Zleft_assembles,1),N_situation);
for n1 = 1:size(Zleft_assembles,1)
    neuron = Zleft_assembles{n1,1}(:);
    for n = 1:N_situation
        Zleft_rate_real_assemble{n1,n} = Zleft_rate_real(neuron,:,:,n);
    end
end
Zright_rate_real_assemble = cell(size(Zright_assembles,1),N_situation);
for n1 = 1:size(Zright_assembles,1)
    neuron = Zright_assembles{n1,1}(:);
    for n = 1:N_situation
        Zright_rate_real_assemble{n1,n} = Zright_rate_real(neuron,:,:,n);
    end
end
Z_rate_real_assemble = cell(size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    neuron = Z_assembles{n1,1}(:);
    for n = 1:N_situation
        Z_rate_real_assemble{n1,n} = Z_rate_real(neuron,:,:,n);
    end
end

p_assemble_LR = cell(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)

        for n = 1:N_situation
            spikes1 = sum(Zleft_rate_real_assemble{n1,n},1);
            spikes2 = sum(Zright_rate_real_assemble{n2,n},1);
            x1 = neural_correlation(1,T1,spikes1,spikes2);
            p_assemble_LR{n1,n2,n} = x1;
            % t = 1:T1;
            % plot(t,x1,'color',[0.2,0.2,0.2]+(n-1)*0.5);
            % hold on;
            % aa = [aa;'between 1st group assemble ',num2str(n1),' and 2nd group assemble ',num2str(n2)];
        end
        % legend(aa);
        % xlabel('time step');title('Neural interactions')
    end
end
p_assemble_LB = cell(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            spikes1 = sum(Zleft_rate_real_assemble{n1,n},1);
            spikes2 = sum(Z_rate_real_assemble{n2,n},1);
            x1 = neural_correlation(1,T1,spikes1,spikes2);
            p_assemble_LB{n1,n2,n} = x1;
        end
    end
end
p_assemble_RB = cell(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            spikes1 = sum(Zright_rate_real_assemble{n1,n},1);
            spikes2 = sum(Z_rate_real_assemble{n2,n},1);
            x1 = neural_correlation(1,T1,spikes1,spikes2);
            p_assemble_RB{n1,n2,n} = x1;
        end
    end
end

% correlation between assembles averaged over neurons and time steps
p_Assemble_LR = zeros(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            clear p0;
            p0 = p_assemble_LR{n1,n2,n};
            p1 = mean(p0);
            if ~isnan(p1)
               p_Assemble_LR(n1,n2,n) = p1;
            else
               p_Assemble_LR(n1,n2,n) = 0; 
            end
        end
    end
end
p_Assemble_RB = zeros(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            clear p0;
            p0 = p_assemble_RB{n1,n2,n};
            p1 = mean(p0);
            if ~isnan(p1)
             p_Assemble_RB(n1,n2,n) = p1;
            else
             p_Assemble_RB(n1,n2,n) = 0;
            end
        end
    end
end
p_Assemble_LB = zeros(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            clear p0;clear p1;
            p0 = p_assemble_LB{n1,n2,n};
            p1 = mean(p0);
            if ~isnan(p1)
              p_Assemble_LB(n1,n2,n) = p1;
            else
              p_Assemble_LB(n1,n2,n) = 0;
            end

        end
    end
end

p_Assemble0 = [p_Assemble_LR(:);p_Assemble_RB(:);p_Assemble_LB(:)];
top0 = max(p_Assemble0(:));bottom0 = min(p_Assemble0(:));

Plot_neural_assemble_interact(top0,bottom0,Z_assembles,Zleft_assembles,p_Assemble_LB,N_situation);
Plot_neural_assemble_interact(top0,bottom0,Zright_assembles,Zleft_assembles,p_Assemble_LR,N_situation);
Plot_neural_assemble_interact(top0,bottom0,Z_assembles,Zright_assembles,p_Assemble_RB,N_situation);


% % Energy between neural assembles in bi-direction communication
% % L&R
% 
% 
% [Energy_assemble_LR1,Energy_assemble_LR2] = Energy_Assemble(Zleft_cout_sti,Zright_cout_sti,net.VRtoL0,net.VLtoR0,net.VRtoL,net.VLtoR,Zleft_assembles,Zright_assembles);
% [Energy_assemble_BR1,Energy_assemble_BR2] = Energy_Assemble(Z_cout_sti,Zright_cout_sti,net.VRtoB0,net.VBtoR0,net.VRtoB,net.VBtoR,Z_assembles,Zright_assembles);
% [Energy_assemble_LB1,Energy_assemble_LB2] = Energy_Assemble(Zleft_cout_sti,Z_cout_sti,net.VBtoL0,net.VLtoB0,net.VBtoL,net.VLtoB,Zleft_assembles,Z_assembles);
% 
% 
% Plot_neural_assemble_energy(Energy_assemble_LR1);
% Plot_neural_assemble_energy(Energy_assemble_BR1);
% Plot_neural_assemble_energy(Energy_assemble_LB1);

% Stimulus modification of neural responses

stimulus_modification_assemble_response(N_situation,N_assemble,Zleft_rate_real,Zleft_assembles);
stimulus_modification_assemble_response(N_situation,N_assemble,Zright_rate_real,Zright_assembles);
stimulus_modification_assemble_response(N_situation,N_assemble,Z_rate_real,Z_assembles);

% Stimulus-induced neural variability
stimulus_induced_assemble_variability(N_assemble,Zleft_rate_real,Zleft_assembles);
stimulus_induced_assemble_variability(N_assemble,Zright_rate_real,Zright_assembles);
stimulus_induced_assemble_variability(N_assemble,Z_rate_real,Z_assembles);

% NMI between assembles 
NMI_assemble = Neural_assemble_NMI(Zleft_spiketrain_real_avetime,Z_spiketrain_real_avetime,net.VLtoB0,net.VBtoL0,Zleft_assembles,Z_assembles);
NMI_assemble = Neural_assemble_NMI(Zleft_spiketrain_real_avetime,Zright_spiketrain_real_avetime,net.VLtoR0,net.VRtoL0,Zleft_assembles,Zright_assembles);
NMI_assemble = Neural_assemble_NMI(Zright_spiketrain_real_avetime,Z_spiketrain_real_avetime,net.VRtoB0,net.VBtoR0,Zright_assembles,Z_assembles);

% contribution of neural assembles in inference

% ex. and in. neural spiking rates
clear Z_cluster;
for m = 1:size(Z_count_sti,4) % select clustering sets assotiated with 3rd group
    clear cluster0
    cluster0 = net.action{1,m};
    Z_cluster(:,:,m) = cluster0;
end

Z_rate_real_contri = zeros(N_neuron,L,size(stimulus,2));
Z_spike_real_contri = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each situation
 for l = 1:L % for each simulation
  clear T2;T2 = net.iden_t(l_style,l);
  Z_spike_real_contri(:,l,l_style) = Z_count_sti(:,T2,l,l_style); % neural spikes at first correct identifications
  for t = 1:T2
   % neural spiking rates at first correct identifications
   Z_rate_real_contri(:,l,l_style) = (Z_rate_real_contri(:,l,l_style) + Z_count_sti(:,t,l,l_style))*exp(-1/20); 
  end
 end
end

Z_distance = zeros(size(Z_count_sti,1)*2,size(Z_count_sti,4));
Z_contri = Z_distance;
Z_distance_spike = zeros(size(Z_count_sti,1),size(Z_count_sti,4));
Z_contri_spike = Z_distance_spike;
Z_distance_rate = Z_distance_spike;
Z_contri_rate = Z_distance_rate;

% distance induced by neural group in inference to different situations
for m = 1:size(Z_count_sti,4)% for each situation
 for ll = 1:size(Z_count_sti,3)% for each simulation
     clear Z_distance0;clear Z_distance_spike0;clear Z_distance_rate0;
     for v = 1:size(Z_cluster,2) % for each vector in each clustering martix
         Z_distance0(:,v) = [Z_spike_real_contri(:,ll,m);Z_rate_real_contri(:,ll,m)] - Z_cluster(:,v,m);
         Z_distance_spike0(:,v) = Z_distance0(1:size(Z_count_sti,1),v);
         Z_distance_rate0(:,v) = Z_distance0(1+size(Z_count_sti,1):end,v);
     end
     Z_distance(:,m) = Z_distance(:,m) + sum((Z_distance0.^2),2);
     Z_distance_spike(:,m) = Z_distance_spike(:,m) + sum((Z_distance_spike0.^2),2);
     Z_distance_rate(:,m) = Z_distance_rate(:,m) + sum((Z_distance_rate0.^2),2);
 end
end




% distance induced by neural group in inference to different situations
for m = 1:size(Z_count_sti,4)% for each situation
 for ll = 1:size(Z_count_sti,3)% for each simulation
     clear Z_distance0;clear Z_distance_spike0;clear Z_distance_rate0;
     for v = 1:size(Z_cluster,2) % for each vector in each clustering martix
         Z_distance0(:,v) = [Z_spike_real_contri(:,ll,m);Z_rate_real_contri(:,ll,m)] - Z_cluster(:,v,m);
         Z_distance_spike0(:,v) = Z_distance0(1:size(Z_count_sti,1),v);
         Z_distance_rate0(:,v) = Z_distance0(1+size(Z_count_sti,1):end,v);
     end
     Z_distance(:,m) = Z_distance(:,m) + sum((Z_distance0.^2),2);
     Z_distance_spike(:,m) = Z_distance_spike(:,m) + sum((Z_distance_spike0.^2),2);
     Z_distance_rate(:,m) = Z_distance_rate(:,m) + sum((Z_distance_rate0.^2),2);
 end
end



clear Zleft_cluster;
Zleft_rate_real_contri = zeros(N_neuron,L,size(stimulus,2));
Zleft_spike_real_contri = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each situation
 for l = 1:L % for each simulation
  clear T2;T2 = net.iden_t(l_style,l);
  Zleft_spike_real_contri(:,l,l_style) = Zleft_count_sti(:,T2,l,l_style); % neural spikes at first correct identifications
  for t = 1:T2
   % neural spiking rates at first correct identifications
   Zleft_rate_real_contri(:,l,l_style) = (Zleft_rate_real_contri(:,l,l_style) + Zleft_count_sti(:,t,l,l_style))*exp(-1/20); 
  end
 end
end
for m = 1:size(Zleft_cout_sti,4) % select clustering sets assotiated with 1st group
    clear cluster0
    cluster0 = net.action{1,m};
    Zleft_cluster(:,:,m) = cluster0(1:size(Zleft_cout_sti,1),:);
end

Zright_rate_real_contri = zeros(N_neuron,L,size(stimulus,2));
Zright_spike_real_contri = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each situation
 for l = 1:L % for each simulation
  clear T2;T2 = net.iden_t(l_style,l);
  Zright_spike_real_contri(:,l,l_style) = Zright_count_sti(:,T2,l,l_style); % neural spikes at first correct identifications
  for t = 1:T2
   % neural spiking rates at first correct identifications
   Zright_rate_real_contri(:,l,l_style) = (Zright_rate_real_contri(:,l,l_style) + Zright_count_sti(:,t,l,l_style))*exp(-1/20); 
  end
 end
end




clear Zleft_spike_overtime;
Zleft_spike_overtime = sum(Zleft_cout_sti,2);

Zleft_distance = zeros(size(Zleft_cout_sti,1),size(Zleft_cout_sti,4));Zleft_contri = Zleft_distance;
% distance induced by 1st neural group in inference to different situations
for m = 1:size(Zleft_cout_sti,4)% for each situation
 for ll = 1:size(Zleft_cout_sti,3)% for each simulation
     clear Zleft_distance0
     for t = 1:size(Zleft_cluster,2)   
         Zleft_distance0(:,t) = Zleft_spike_overtime(:,1,ll,m) - Zleft_cluster(:,t,m);
     end
     Zleft_distance(:,m) = Zleft_distance(:,m) + sum((Zleft_distance0.^2),2);
 end
end

clear Zright_spike_overtime;clear Zright_cluster;
Zright_spike_overtime = sum(Zright_cout_sti,2);
for m = 1:size(Zright_cout_sti,4) % select clustering sets assotiated with 2nd group
    clear cluster0
    cluster0 = net.action{1,m};
    Zright_cluster(:,:,m) = cluster0(size(Zright_cout_sti,1)+1:2*size(Zright_cout_sti,1),:);
end
Zright_distance = zeros(size(Zright_cout_sti,1),size(Zright_cout_sti,4));Zright_contri = Zright_distance;
% distance induced by 2nd neural group in inference to different situations
for m = 1:size(Zright_cout_sti,4)% for each situation
 for ll = 1:size(Zright_cout_sti,3)% for each simulation
     clear Zright_distance0
     for t = 1:size(Zleft_cluster,2)   
         Zright_distance0(:,t) = Zright_spike_overtime(:,1,ll,m) - Zright_cluster(:,t,m);
     end
     Zright_distance(:,m) = Zright_distance(:,m) + sum((Zright_distance0.^2),2);
 end
end

clear Z_spike_overtime;clear Z_cluster;
Z_spike_overtime = sum(Z_cout_sti,2);
for m = 1:size(Z_cout_sti,4) % select clustering sets assotiated with 3rd group
    clear cluster0
    cluster0 = net.action{1,m};
    Z_cluster(:,:,m) = cluster0(2*size(Z_cout_sti,1)+1:3*size(Z_cout_sti,1),:);
end
Z_distance = zeros(size(Z_cout_sti,1),size(Z_cout_sti,4));Z_contri = Z_distance;
% distance induced by 3rd neural group in inference to different situations
for m = 1:size(Z_cout_sti,4)% for each situation
 for ll = 1:size(Z_cout_sti,3)% for each simulation
     clear Z_distance0
     for t = 1:size(Zleft_cluster,2)   
         Z_distance0(:,t) = Z_spike_overtime(:,1,ll,m) - Z_cluster(:,t,m);
     end
     Z_distance(:,m) = Z_distance(:,m) + sum((Z_distance0.^2),2);
 end
end

% with the Maximum of distance, neural contributions in inference are
% measured
Zleft_contri = zeros(size(Zleft_distance));
Zright_contri = zeros(size(Zright_distance));
Z_contri = zeros(size(Z_distance));
clear max_distance;
for m = 1:2
    max_distance(m) = max([Zleft_distance(:,m);Zright_distance(:,m);Z_distance(:,m)]);
    Zleft_contri(:,m) = 1 - Zleft_distance(:,m)/max_distance(m);
    Zright_contri(:,m) = 1 - Zright_distance(:,m)/max_distance(m);
    Z_contri(:,m) = 1 - Z_distance(:,m)/max_distance(m);
end



% plot neural contributions in inference
clear contr_mu;clear contr_std;% average and standard variance of contributions in situations
contr_mu(1,1) = mean(Zleft_contri(:,1));contr_std(1,1) = std(Zleft_contri(:,1));
contr_mu(1,2) = mean(Zleft_contri(:,2));contr_std(1,2) = std(Zleft_contri(:,2));
contr_mu(2,1) = mean(Zright_contri(:,1));contr_std(2,1) = std(Zright_contri(:,1));
contr_mu(2,2) = mean(Zright_contri(:,2));contr_std(2,2) = std(Zright_contri(:,2));
contr_mu(3,1) = mean(Z_contri(:,1));contr_std(3,1) = std(Z_contri(:,1));
contr_mu(3,2) = mean(Z_contri(:,2));contr_std(3,2) = std(Z_contri(:,2));


% contributions of neural assemble in inference
Zleft_assemble_contri = cell(3,2);% contribution of each assemble in 1st group in inference
for n_assemble = 1:size(Zleft_assembles,1)
    neuron = Zleft_assembles{n_assemble, 1};
    for m = 1:2% in each situation
        Zleft_assemble_contri{n_assemble,m} = Zleft_contri(neuron,m);
    end
end

Zright_assemble_contri = cell(3,2);% contribution of each assemble in 2nd group in inference
for n_assemble = 1:size(Zright_assembles,1)
    neuron = Zright_assembles{n_assemble, 1};
    for m = 1:2% in each situation
        Zright_assemble_contri{n_assemble,m} = Zright_contri(neuron,m);
    end
end

Z_assemble_contri = cell(3,2);% contribution of each assemble in 3rd group in inference
for n_assemble = 1:size(Z_assembles,1)
    neuron = Z_assembles{n_assemble, 1};
    for m = 1:2% in each situation
        Z_assemble_contri{n_assemble,m} = Z_contri(neuron,m);
    end
end

% neural assembles in 1st group in two situations
% average and standard variance of contributions in situations
clear contr_mu;clear contr_std;
for n1 = 1:size(Zleft_assemble_contri,1)
    for n2 = 1:size(Zleft_assemble_contri,2)
        clear contri0;
        contri0 = Zleft_assemble_contri{n1,n2};
        contr_mu(n1,n2) = mean(contri0(:));contr_std(n1,n2) = std(contri0(:));
    end
end
figure;
for mm = 1:2
y1 = contr_mu(:,mm);
b = bar(y1');
 for nn = 1:3
  b(nn).FaceColor = [0.2 0.2 0.2]*nn;
 end
 hold on;
end
ylim([0 1.2]);

% neural assembles in 2nd group in two situations
% average and standard variance of contributions in situations
clear contr_mu;clear contr_std;
for n1 = 1:size(Zright_assemble_contri,1)
    for n2 = 1:size(Zright_assemble_contri,2)
        clear contri0;
        contri0 = Zright_assemble_contri{n1,n2};
        contr_mu(n1,n2) = mean(contri0(:));contr_std(n1,n2) = std(contri0(:));
    end
end
figure;
for mm = 1:2
x = mm;
y1 = contr_mu(:,mm);
b = bar(x,y1);
 for nn = 1:3
  b(nn).FaceColor = [0.2 0.2 0.2]*nn;
 end
 hold on;
end
ylim([0 1.2]);

% neural assembles in 3rd group in two situations
% average and standard variance of contributions in situations
clear contr_mu;clear contr_std;
for n1 = 1:size(Z_assemble_contri,1)
    for n2 = 1:size(Z_assemble_contri,2)
        clear contri0;
        contri0 = Z_assemble_contri{n1,n2};
        contr_mu(n1,n2) = mean(contri0(:));contr_std(n1,n2) = std(contri0(:));
    end
end
figure;
for mm = 1:2
x = mm;
y1 = contr_mu(:,mm);
b = bar(x,y1);
 for nn = 1:3
  b(nn).FaceColor = [0.2 0.2 0.2]*nn;
 end
 hold on;
end
ylim([0 1.2]);

% sparseness of neural assemble in the 1st ex. group
xbin = 0:0.2:1;
clear a1;clear b1;
for n_assemble = 1:size(Zleft_assembles,1)% for each neural assemble in the 1st ex. group
    clear neuron;clear sparse0;
    neuron = Zleft_assembles{n_assemble,1};
    sparse0 = sparseness_Zleft(neuron);
    % freq. of sparseness of each neural assemble
    [a0,b0] = hist(sparse0(:),xbin);
    a1(:,n_assemble) = a0./sum(a0);
    b1 = b0;
end
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'assemble ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
ylim([0 1.1]);
legend(aa);

% sparseness of neural assemble in the 2nd ex. group
xbin = 0:0.2:1;
clear a1;clear b1;
for n_assemble = 1:size(Zright_assembles,1)% for each neural assemble in the 2nd ex. group
    clear neuron;clear sparse0;
    neuron = Zright_assembles{n_assemble,1};
    sparse0 = sparseness_Zright(neuron);
    % freq. of sparseness of each neural assemble
    [a0,b0] = hist(sparse0(:),xbin);
    a1(:,n_assemble) = a0./sum(a0);
    b1 = b0;
end
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'assemble ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
ylim([0 1.1]);
legend(aa);

% sparseness of neural assemble in the 3rd ex. group
xbin = 0:0.2:1;
clear a1;clear b1;
for n_assemble = 1:size(Z_assembles,1)% for each neural assemble in the 3rd ex. group
    clear neuron;clear sparse0;
    neuron = Z_assembles{n_assemble,1};
    sparse0 = sparseness_Z(neuron);
    % freq. of sparseness of each neural assemble
    [a0,b0] = hist(sparse0(:),xbin);
    a1(:,n_assemble) = a0./sum(a0);
    b1 = b0;
end
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'assemble ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
ylim([0 1.1]);
legend(aa);



end