function [Z_j,K] = wta_draw_k2(P_t,Z,j)
%
% [Z_j,k] = wta_draw_k2(P_t,Z,j)
%
% Draw a random sample vector Z from a distribution P.
% P is assumed to be normalised over columns, so for
% each column a sample is drawn. Output has the same
% dimensionality as P.
%
% 05.08.2011
%
%     r = P(:,end);
%     b = (random('Poisson',r)>0);
       Z_j = zeros(size(P_t,1),1);
       for n = 1:size(P_t,1)
           if (unifrnd(0,1,1,1)<P_t(n,1))
                Z_j(n,1) = 1;
           end
       end
       
       c1 = floor(max(1,j-5));c2 = floor(max(1,j));
       Z1 = sum(Z(:,c1:c2),2);
       Z_j = (Z1<1).*Z_j;
       K = find(Z_j==1);
%     
%     k = find( cumsum(P_t,1) > rand(), 1 );
%      if isempty(k)
%         k = size(P_t,1);
%      end
%     
%     Z = sparse( k, 1, 1, size(P_t,1), 1 );
end
